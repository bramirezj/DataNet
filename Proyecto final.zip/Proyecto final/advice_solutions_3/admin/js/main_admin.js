function user_info_popover_tooltip_repositioning(){
    if(document.getElementById("nav_user_image") != null){
        setTimeout(function(){
            $('#user_info').popover('update');
            $('#user_info_icon').tooltip('update');
        }, 10);
    }
}

function user_info_popover_tooltip_repositioning_timed(){
    if((document.getElementById("nav_user_image") != null) && ($(window).width() < 992)){
        var user_name_tooltip_reposition = setInterval(function(){
            $('#user_info').popover('update');
            $('#user_info_icon').tooltip('update');
        }, 1);

        setTimeout(function(){
            clearInterval(user_name_tooltip_reposition);
        }, 410);
    }
}

function logout(){
    if(confirm("¿Estás seguro de cerrar la sesión?")){
        location.href = "sources/logout.php";
    }
}

function build_popover_tooltip_content(type){
    var content = '';

    switch(type){
        case 0:
            content =
                '<div class="text-center">' +
                    '<button class="btn btn-danger w-100" onclick="logout()">' +
                        '<i class="fas fa-power-off fa-2x my-1"></i>' +
                    '</button>' +
                '</div>';
        break;
    }

    return content;
}

$(document).ready(function(){
    $('#user_info').popover({
        container: '#user_info_pane',
        placement: 'bottom',
        sanitize: false,
        html: true,
        title: 'Cerrar sesión',
        content: build_popover_tooltip_content(0)
    });

    $('#user_info_icon').tooltip({
        container: "#user_info",
        placement: "left"
    });

    $('#user_info_icon').tooltip("show");
    $('#user_info_icon').unbind();

    $('#main_navbar').on('show.bs.collapse', function(){
        user_info_popover_tooltip_repositioning();
    });

    (function(){
        'use strict';
        window.addEventListener('load', function(){
            Array.prototype.filter.call(document.getElementsByClassName('needs-validation'), function(form){
                if(typeof InstallTrigger === 'undefined'){
                    form.noValidate = true;
                }

                form.addEventListener('submit', function(event){
                    if (form.checkValidity() === false){
                        event.preventDefault();
                        event.stopPropagation();
                    }else{
                        $('.modal').modal('hide');
                    }
    
                    form.classList.add('was-validated');
                }, false);
            });
        }, false);
    })();

    user_info_popover_tooltip_repositioning();
});