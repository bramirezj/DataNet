<?php
    session_start();
    
    if(isset($_SESSION["token_admin"])){
        unset($_SESSION["token_admin"]);
    }
	
	session_destroy();
    
	header("Cache-Control: no-cache, must-revalidate");
	header("Pragma: no-cache");
	header("Location: ../login_admin_frm.php");
    exit();
?>