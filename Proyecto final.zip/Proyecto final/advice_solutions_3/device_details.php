<?php
    session_start();
    
    $sql_string = "";

    $device_details = array(
        "id" => "",
        "model" => "N/A",
        "brand" => "N/A",
        "stock" => "N/A",
        "price" => "N/A",
        "processor" => "N/A",
        "ram" => 0,
        "graphic_card" => "N/A",
        "storage" => 0
    );

    if(isset($_GET["device_id"])){
        $sql_string = sprintf("select * from devices_images dvi, devices dv where dvi.device =".$_GET["device_id"]." and dv.id=".$_GET["device_id"]." ;");
        echo $sql_string;
    }

    include_once("sources/starting_vars.php");

    if($mysql_query = mysqli_store_result($mysql_connection)){
        $tuple = mysqli_fetch_assoc($mysql_query);

        $device_details["id"] = $tuple["id"];
        $device_details["model"] = $tuple["model"];
        $device_details["brand"] = $tuple["brand"];
        $device_details["stock"] = $tuple["stock"];
        $device_details["price"] = $tuple["price"];
        $device_details["processor"] = $tuple["processor"];
        $device_details["ram"] = $tuple["ram"];
        $device_details["graphic_card"] = $tuple["graphic_card"];
        $device_details["storage"] = $tuple["storage"];

        mysqli_free_result($mysql_query);
    }else{
        $error["error_no"] = "0003";
        $error["error_msj"] = "No se pudo cargar toda la información del dispositivo debido a un problema con el servidor.";
    }
?>

<!DOCTYPE html>

<html lang="en-US">
    <head>
        <?php
            include_once("sources/dependencies.php");
            include_once("sources/scripts_fxs.php");
        ?>

        <link rel="stylesheet" type="text/css" href="lib/datatables/css/dataTables.bootstrap4.css" />
        <link rel="stylesheet" type="text/css" href="css/backgrounds_sty.css" />
        <link rel="stylesheet" type="text/css" href="css/store_sty.css" />
        
        <script type="text/javascript" src="lib/datatables/js/jquery.dataTables.js"></script>
        <script type="text/javascript" src="lib/datatables/js/dataTables.bootstrap4.js"></script>
        <script type="text/javascript" src="js/store_src.js"></script>

        <title>, Detalles del dispositivo | Advice & Solutions</title>
    </head>

    <body>
        <header>
            <?php include_once("includes/header.inc"); ?>
        </header>

        <main>
            <?php
                if($on_session){
                    include_once("includes/change_user_image_modal.inc");
                }
            ?>

            <div class="container">
                <div class="row">
                    <div id="top_space" class="col-lg-12"></div>
                </div>

                <div class="row">
                    <div class="col-lg-12">
                        <?php include_once("includes/alerts.inc"); ?>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-12 pb-3">
                        <div class="card border-0 shadow">
                            <div class="card-body">
                                <h4 class="card-title">
                                    <div id="equipo" class="equipo" >
                                        <div class="container">
                                        
                                            <div class="row wow animate__animated animate__zoomIn animate__delay-0.1s">
                                                <div class="col-12">
                                                    <br>
                                                <h2 class="page-header">Detalles del Equipo</h2>
                                                <br>
                                                </div>
                                            <div class="col-lg-6 mb-4">
                                                
                                                <div class="">
                                                <div class="main-product-image space">
                                                    <div id="product-carousel" class="carousel slide">
                                                    <div class="carousel-inner" role="listbox">
                                                        <div class="carousel-item active">
                                                        <?php echo '<img id="1" src="data:'.$tuple['device_image_type'].';base64,'.base64_encode($tuple['device_image_data']).'" width="500px" height="500px" class="img-fluid">';?>
                                                        </div>
                                                        <div class="carousel-item">
                                                        <?php echo '<img id="1" src="data:'.$tuple['device_image_type'].';base64,'.base64_encode($tuple['device_image_data']).'" width="500px" height="500px" class="img-fluid">';?>
                                                        </div>
                                                    
                                                    </div>
                                                    </div>
                                                    <a class="carousel-control-prev" href="#product-carousel" role="button" data-slide="prev">
                                                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                                    <span class="sr-only">Previous</span>
                                                    </a>
                                                    <a class="carousel-control-next" href="#product-carousel" role="button" data-slide="next">
                                                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                                    <span class="sr-only">Next</span>
                                                    </a>

                                                </div>
                                                </div><br>
                                            
                                                
                                            
                                            </div>
                                        
                                            <div class="col-lg-6">
                                            <div class="col-sm-8 col-md-9 description">
                                                        <ul class="list-unstyled li-space-lg">

                                                            <li class="media">
                                                                <table>
                                                                    <tr>
                                                                        <td style="color: #ffc107;">
                                                                        <i class="fas fa-square"></i>
                                                                        </td>
                                                                        <td>
                                                                        <div class="media-body"><strong>&nbsp;Codigo:</strong><?php  echo $tuple["id"]; ?><input type="hidden" id="id" name="id" value= "<?php  echo $tuple["id"]; ?>"></div>
             
                                                                        </td>
                                                                    </tr>
                                                                </table>
                                                            
                                                            </li>                    
                                                        </ul> 
                                                        <ul class="list-unstyled li-space-lg">
                                                            <li class="media">
                                                                <table>
                                                                    <tr>
                                                                        <td style="color: #ffc107;">
                                                                        <i class="fas fa-square"></i>
                                                                        </td>
                                                                        <td>
                                                                        <div class="media-body"><strong>&nbsp;Modelo:</strong><?php echo $tuple["model"]; ?></div>
                                                                        </td>
                                                                    </tr>
                                                                </table>
                                                            
                                                            </li>                    
                                                        </ul> 
                                                        <ul class="list-unstyled li-space-lg">
                                                            <li class="media">
                                                                <table>
                                                                    <tr>
                                                                        <td style="color: #ffc107;">
                                                                        <i class="fas fa-square"></i>
                                                                        </td>
                                                                        <td>
                                                                        <div class="media-body"><strong>&nbsp;Marca:</strong> <?php echo $tuple["brand"]; ?></div>
                                                                        </td>
                                                                    </tr>
                                                                </table>
                                                            
                                                            </li>                   
                                                        </ul> 
                                                        <ul class="list-unstyled li-space-lg">
                                                            <li class="media">
                                                                <table>
                                                                    <tr>
                                                                        <td style="color: #ffc107;">
                                                                        <i class="fas fa-square"></i>
                                                                        </td>
                                                                        <td>
                                                                        <div class="media-body"><strong>&nbsp;Precio:</strong><input type="hidden" id="price" name="price" value= "<?php echo $tuple["price"]; ?>"></div>
                                                                        </td>
                                                                    </tr>
                                                                </table>
                                                            
                                                            </li>                   
                                                        </ul>
                                                        <ul class="list-unstyled li-space-lg">
                                                            <li class="media">
                                                                <table>
                                                                    <tr>
                                                                        <td style="color: #ffc107;">
                                                                        <i class="fas fa-square"></i>
                                                                        </td>
                                                                        <td>
                                                                        <div class="media-body"><strong>&nbsp;RAM:</strong> <?php echo $tuple["ram"]; ?></div>
                                                                        </td>
                                                                    </tr>
                                                                </table>
                                                            
                                                            </li>                   
                                                        </ul>
                                                        <ul class="list-unstyled li-space-lg">
                                                            <li class="media">
                                                                <table>
                                                                    <tr>
                                                                        <td style="color: #ffc107;">
                                                                        <i class="fas fa-square"></i>
                                                                        </td>
                                                                        <td>
                                                                        <div class="media-body"><strong>&nbsp;Tarjeta Grafica:</strong> <?php echo $tuple["graphic_card"]; ?></div>
                                                                        </td>
                                                                    </tr>
                                                                </table>
                                                            
                                                            </li>                   
                                                        </ul>
                                                        <ul class="list-unstyled li-space-lg">
                                                            <li class="media">
                                                                <table>
                                                                    <tr>
                                                                        <td style="color: #ffc107;">
                                                                        <i class="fas fa-square"></i>
                                                                        </td>
                                                                        <td>
                                                                        <div class="media-body"><strong>&nbsp;Almacenamiento:</strong> <?php echo $tuple["storage"]; ?></div>
                                                                        </td>
                                                                    </tr>
                                                                </table>
                                                            
                                                            </li>                   
                                                        </ul>
                                                        <ul class="list-unstyled li-space-lg">
                                                            <li class="media">
                                                                <table>
                                                                    <tr>
                                                                        <td style="color: #ffc107;">
                                                                        <i class="fas fa-square"></i>
                                                                        </td>
                                                                        <td>
                                                                        <div class="media-body"><strong>&nbsp;Cantidad a comprar:</strong><input id="qty" type="number" style="width :50px"></div>
                                                                        </td>
                                                                    </tr>
                                                                </table>
                                                            
                                                            </li>                   
                                                        </ul>
                                                        <br>
                                                        <button onclick="insertar()" class="btn btn-warning rounded-pill" >Agregar al carrito</button>
                                                       
                                            </div>
                                                
                                            </div>
                                            
                                            </div>
                                        
                                        </div>
                                    </div>
                                </h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>

        <footer>
            <?php include_once("includes/footer.inc"); ?>
        </footer>
    </body>
</html>

<script> 

function insertar () {
    

    var device_id= document.getElementById('id').value;
    var qty= document.getElementById('qty').value;
    var price= document.getElementById('price').value;


 

    console.log(device_id);
    console.log(qty);
    console.log(price);
    location.href = "insert.php?device_id="+device_id+"&qty="+qty+"&price="+price;
    
    
}



</script>