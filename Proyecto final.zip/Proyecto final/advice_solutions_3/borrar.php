<?php
    session_start();
    
    include_once("sources/starting_vars.php");
    
 
    
   $sql_string = "delete from dt_shop_cart where id=".$_GET['id'];
   $mysql_query = mysqli_store_result($mysql_connection);
   $mysql_query = mysqli_query($mysql_connection, $sql_string) or die(mysqli_error($mysql_connection));

   header("Location:shop_cart.php");
  
?>