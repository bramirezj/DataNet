<?php
    session_start();
    
    $sql_string = "select * from vw_devices;";

    include_once("sources/starting_vars.php");
?>

<!DOCTYPE html>

<html lang="en-US">
    <head>
        <?php
            include_once("sources/dependencies.php");
            include_once("sources/scripts_fxs.php");
        ?>

        <link rel="stylesheet" type="text/css" href="lib/datatables/css/dataTables.bootstrap4.css" />
        <link rel="stylesheet" type="text/css" href="css/backgrounds_sty.css" />
        <link rel="stylesheet" type="text/css" href="css/store_sty.css" />
        
        <script type="text/javascript" src="lib/datatables/js/jquery.dataTables.js"></script>
        <script type="text/javascript" src="lib/datatables/js/dataTables.bootstrap4.js"></script>
        <script type="text/javascript" src="js/store_src.js"></script>

        <title>Tienda de dispositivos | Advice & Solutions</title>
    </head>

    <body>
        <header>
            <?php include_once("includes/header.inc"); ?>
        </header>

        <main>
            <?php
                if($on_session){
                    include_once("includes/change_user_image_modal.inc");
                }
            ?>

            <div class="container-fluid">
                <div class="row">
                    <div id="top_space" class="col-lg-12"></div>
                </div>

                <div class="row">
                    <div class="col-lg-12">
                        <?php include_once("includes/alerts.inc"); ?>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-12 pb-3">
                        <?php
                            if($mysql_query = mysqli_store_result($mysql_connection)){
                                if(mysqli_num_rows($mysql_query) > 0){
                                    echo '
                                        <table id="tb_devices_list" class="w-100">
                                            <thead>
                                                <tr>
                                                    <th class="pb-2">
                                                        <div class="bg-secondary text-light text-center rounded shadow pt-1 pb-1">
                                                            <h5 class="mb-0">
                                                                <strong>Tienda de dispositivos</strong>
                                                            </h5>
                                                        </div>
                                                    </th>
                                                </tr>
                                            </thead>

                                            <tbody>
                                    ';

                                    while($tuple = mysqli_fetch_assoc($mysql_query)){
                                        echo '
                                                <tr>
                                                    <td class="pb-2">
                                                        <div class="card border-0 shadow">
                                                            <div class="card-body">
                                                                <div class="row text-center">
                                                                    <div class="col-lg-3 device-image">
                                                                        <img src="sources/get_device_image.php?device_id='.$tuple["id"].'" alt="'.$tuple["model"].'" height="140" />
                                                                    </div>

                                                                    <div class="col-lg-6 device-pane-1">
                                                                        <h5 class="card-title">
                                                                            <strong>'.$tuple["model"].'</strong>
                                                                        </h5>

                                                                        <span>¢'.number_format($tuple["price"], 2, ',', ' ').'</span>
                                                                    </div>

                                                                    <div class="col-lg-3 device-pane-2">
                                                                        <h6 class="mb-3">
                                                                            '.(($tuple["stock"] > 0) ? '<strong>Disponibles: </strong>'.$tuple["stock"] : '<strong class="text-warning">Agotado</strong>').'
                                                                        </h6>

                                                                        <a href="device_details.php?device_id='.$tuple["id"].'" class="btn btn-warning rounded-pill">
                                                                            <strong>Ver dispositivo</strong>
                                                                        </a>
                                                                    </div>  
                                                                </div>    
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                        ';
                                    }

                                    echo '
                                            </tbody>
                                        </table>
                                    ';
                                }else{
                                    echo '
                                    
                                    ';
                                }
                        
                                mysqli_free_result($mysql_query);
                            }
                        ?>
                    </div>
                </div>
            </div>
        </main>

        <footer>
            <?php include_once("includes/footer.inc"); ?>
        </footer>
    </body>
</html>