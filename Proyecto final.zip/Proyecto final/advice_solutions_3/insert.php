<?php 

    session_start();
    
    include_once("sources/starting_vars.php");
    
    $sql_string = "select user_token from shop_cart where user_token='".$_SESSION["token"]."'";
    // $mysql_query = mysqli_store_result($mysql_connection);
    $mysql_query = mysqli_query($mysql_connection, $sql_string) or die(mysqli_error($mysql_connection));

    echo mysqli_num_rows($mysql_query);
    

    if(mysqli_num_rows($mysql_query) == 0 ){

        $sql_string = "insert into shop_cart (user_token) values('".$_SESSION["token"]."') ";
        $mysql_query = mysqli_query($mysql_connection, $sql_string) or die(mysqli_error($mysql_connection));
        $sql_string = "insert into dt_shop_cart (id_sp, id_device, qty, taxes, price) 
        values( (select id from shop_cart where user_token = '".$_SESSION["token"]."'), '".$_GET["device_id"]."', '".$_GET["qty"]."',0.13,'".$_GET["price"]."') ";
        $mysql_query = mysqli_query($mysql_connection, $sql_string) or die(mysqli_error($mysql_connection));
    }

    else{

        $sql_string = "insert into dt_shop_cart (id_sp, id_device, qty, taxes, price) 
        values( (select id from shop_cart where user_token = '".$_SESSION["token"]."'), '".$_GET["device_id"]."', '".$_GET["qty"]."',0.13,'".$_GET["price"]."') ";
        $mysql_query = mysqli_query($mysql_connection, $sql_string) or die(mysqli_error($mysql_connection));
    }


    header("Location:shop_cart.php");
 
?>