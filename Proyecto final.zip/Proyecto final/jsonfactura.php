<?php
    header("Content-Type:application/json");
	header("Accept:application/json");

    function deliver_response($status, $status_message, $data){
		header("HTTP/1.1 $status $status_message");
		
		$response["status"] = $status;
		$response["status_message"] = $status_message;
		$response["data"] = $data;
		
		echo json_encode($response);
	}

	$request = explode("/", substr(@$_SERVER['PATH_INFO'], 1));

	switch ($_SERVER['REQUEST_METHOD']){
        case 'GET':
            if(sizeof($request) == 1){
				if($request[0] == 'factura'){					
					$datos= array(
                        'clave' => '123456789',
                        'codigoactividad' => '01',
                        'numeroconsecutivo' => '1',
                        'fechaemision' => date("d-m-Y"),
                        'emisor' => array(
                            'nombre' => utf8_decode('advicesolutions'),
                            'id' => array(
                                'tipoid' => '01',
                                'numeroid' => '1111111111111111'
                            ),
                            'ubicacion' => array(
                                'direccion' => utf8_decode('Miramar, Puntarenas')
                            ),
                            'telefono' => array(
                                'codigop' => '506',
                                'numero' => '8888-8888'
                            ),
                            'email' => 'advicesolutions@gmail.com'
                        ),
                        'receptor' => array(
                            'nombre' => utf8_decode('Brandon RamÃ­rez JimÃ©nez'),
                            'id' => array(
                                'tipoid' => '02',
                                'numeroid' => '2222222222222222'
                            ),
                            'ubicacion' => array(
                                'direccion' => utf8_decode('Barranca, Puntarenas')
                            ),
                            'telefono' => array(
                                'codigop' => '506',
                                'numero' => '7189-5643'
                            ),
                            'email' => 'bramirezjime@gmail.com'
                        ),
                        'detalleservicio' => array(
                            'lineadetalle' => [
                                array(
                                    'numerolinea' => '1',
                                    'codproducto' => 'b11mo',
                                    'cantidad' => '1',
                                    'detalleproducto' => 'msi b11mo',
                                    'preciouni' => '650000',
                                    'montotal' => '650000',
                                    'tarifa' => '0.13',
                                    'impuesto' => '84500',
                                    'montolinea' => '734500'
                                ),
                                array(
                                    'numerolinea' => '2',
                                    'codproducto' => 'apple2017',
                                    'cantidad' => '1',
                                    'detalleproducto' => 'Mackbook Pro 2017',
                                    'preciouni' => '850000',
                                    'montotal' => '850000',
                                    'tarifa' => '0.13',
                                    'impuesto' => '110500',
                                    'montolinea' => '960500'
                                )
                            ]
                        ),
                        'resumenfactura' => array(
                            'codtipomoneda' => array(
                                'codmoneda' => 'CRC'
                            ),
                            'totalventa' => '650000',
                            'descuentos' => '0',
                            'totalventaneta' => '650000',
                            'totalimpuesto' => '84500',
                            'total' => '734500'
                        ),
                        'firmadigital' => array(
                            'firma' => 'aqui va la firma digital'
                        )
                    );

                    deliver_response(200, "OK", $datos);
				}else{
                    deliver_response(204, "No Content", "Your request is empty.");  
                }
			}else{
				deliver_response(204, "No Content", "Your request is empty.");  
			}
        break;
    }
?>