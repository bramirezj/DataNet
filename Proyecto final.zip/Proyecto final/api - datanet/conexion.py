import psycopg2


connection=psycopg2.connect(
    host='localhost',
    user='postgres',
    password='utn',
    database='postgres',
    )
cursor=connection.cursor()


def consulta(id: int) -> bool:
    resultado=False
    cursor.execute("SELECT COUNT(1) FROM clientes WHERE idusuario =%s;", (id,))
    rows=cursor.fetchall()
    
    if (rows[0][0]==1):
        resultado=True
    
    return resultado
    
  

# cursor.execute("SELECT COUNT(1) FROM clientes WHERE idusuario = 1")
# rows=cursor.fetchall()
# # for row in rows:
# print(rows[0][0])
