from lxml import etree
import lxml

def validate(xml_path: str, xsd_path: str) -> bool:

    xmlschema_doc = etree.parse(xsd_path)
    
    xmlschema = etree.XMLSchema(xmlschema_doc)
    xml_file = lxml.etree.XML(xml_path)
    result = xmlschema.validate(xml_file)

    return result