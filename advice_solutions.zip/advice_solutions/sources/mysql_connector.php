<?php
	$server = "127.0.0.1";
    $database = "advice_solutions";
    $root_user = "root";
    $root_user_pass = "";
    $mysql_connection = null;

    //error_reporting(0);

    if(!$mysql_connection = mysqli_connect($server, $root_user, $root_user_pass, $database)){
        echo "
            <h3>
                <font color='red'>Error: Hubo un problema con el servidor.</font>
            </h3>
            <hr>
            <strong>Número........:</strong> " . mysqli_connect_errno() . "<br>
            <strong>Descripción...:</strong> " . mysqli_connect_error() . "<br>
        ";

        exit;          
    }   
?>