<?php
    include_once("mysql_connector.php");
    session_start();

    $_SESSION["error"] = array("error_no" => "0000", "error_msj" => "");
    $on_error = false;
    $mysql_query = null;

    $sql_string = sprintf(
        "call login('%s', '%s')",
        $_POST['txt_login_username_email'],
        $_POST['txt_login_password']
    );

    if($mysql_query = mysqli_query($mysql_connection, $sql_string)){
        if(mysqli_num_rows($mysql_query) > 0){
            $_SESSION["token"] = mysqli_fetch_assoc($mysql_query)["token"];
        }else{
            $on_error = true;

            $_SESSION["error"]["error_no"] = "0001";
            $_SESSION["error"]["error_msj"] = "Los datos de autenticación son incorrectos, por favor vuelva a intentarlo o regístrese si no lo estás.";
        }

        if($mysql_query != null){
            mysqli_free_result($mysql_query);
        }
    }else{
        $on_error = true;

        $_SESSION["error"]["error_no"] = "0003";
        $_SESSION["error"]["error_msj"] = "No se pudo conectar debido a un problema con el servidor.";
    }

    unset($_POST['txt_login_username_email']);
    unset($_POST['txt_login_password']);

    if(isset($_SESSION["token"]) && ($_SESSION["token"] != "") && !$on_error){
        header("location: ../user_window.php");
        exit();
    }else{
        header("location: ".$_SERVER["HTTP_REFERER"]);
        exit();
    }
?>