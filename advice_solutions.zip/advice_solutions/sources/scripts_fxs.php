<?php
    echo '
        <script>
            show_user_info("'.$user_info["first_name"].'", "'.$user_info["last_name"].'", "'.$user_info["email"].'");
        </script>
    ';
?>