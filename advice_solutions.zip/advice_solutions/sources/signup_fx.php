<?php
    include_once("mysql_connector.php");
    session_start();

    $_SESSION["error"] = array("error_no" => "0000", "error_msj" => "");
    $on_error = false;

    if($_POST["txt_signup_new_password"] == $_POST["txt_signup_repeat_password"]){
        $mysql_reg_query = null;

        $sql_string = sprintf(
            "call signup('%s', '%s', '%s', '%s', '%s', '%s', '%s')",
            utf8_encode($_POST['txt_signup_first_name']),
            utf8_encode($_POST['txt_signup_last_name']),
            $_POST['sel_signup_user_role'],
            $_POST['txt_signup_username'],
            $_POST['txt_signup_phone'],
            $_POST['txt_signup_email'],
            $_POST['txt_signup_new_password']
        );
        
        if($mysql_reg_query = mysqli_query($mysql_connection, $sql_string)){
            if(mysqli_num_rows($mysql_reg_query) > 0){
                $_SESSION["token"] = mysqli_fetch_assoc($mysql_reg_query)["token"];
            }else{
                $on_error = true;

                $_SESSION["error"]["error_no"] = "0003";
                $_SESSION["error"]["error_msj"] = "No se pudo registrar el usuario correctamente debido a un problema con el servidor.";
            }

            if($mysql_reg_query != null){
                mysqli_free_result($mysql_reg_query);
            }
        }else{
            $on_error = true;
            $errno = mysqli_errno($mysql_connection);

            if($errno == "1062"){
                $_SESSION["error"]["error_no"] = $errno;
                $_SESSION["error"]["error_msj"] = "El nombre de usuario, el número de teléfono o el e-Mail ya se encuentran registrados, por favor vuelva a intentarlo.";
            }else{
                $_SESSION["error"]["error_no"] = "0003";
                $_SESSION["error"]["error_msj"] = "No se pudo registrar el usuario correctamente debido a un problema con el servidor.";
            }
        }
    }else{
        $on_error = true;

        $_SESSION["error"]["error_no"] = "0002";
        $_SESSION["error"]["error_msj"] = "Las contraseñas no coinciden, por favor vuelva a intentarlo.";
    }

    unset($_POST['txt_signup_first_name']);
    unset($_POST['txt_signup_last_name']);
    unset($_POST['sel_signup_user_role']);
    unset($_POST['txt_signup_username']);
    unset($_POST['txt_signup_phone']);
    unset($_POST['txt_signup_email']);
    unset($_POST['txt_signup_new_password']);
    unset($_POST['txt_signup_repeat_password']);

    if(isset($_SESSION["token"]) && ($_SESSION["token"] != "") && !$on_error){
        header("location: ../user_window.php");
        exit();
    }else{
        header("location: ".$_SERVER["HTTP_REFERER"]);
        exit();
    }
?>