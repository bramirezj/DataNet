<?php
    include_once("mysql_connector.php");
    session_start();

    if(isset($_GET["device_id"])){
        $sql_string = "";

        if(isset($_GET["device_image_id"])){
            $sql_string = sprintf("call get_specific_device_image('%s', '%s')", $_GET["device_image_id"], $_GET["device_id"]);
        }else{
            $sql_string = sprintf("call get_first_device_image('%s')", $_GET["device_id"]);
        }

        $mysql_query = mysqli_query($mysql_connection, $sql_string) or die(mysqli_error($mysql_connection));

        if(mysqli_num_rows($mysql_query) > 0){
            $tuple = mysqli_fetch_assoc($mysql_query);
            $type = "";

            switch($tuple['device_image_type']){
                case "image/jpeg":
                    $type = "jpg";
                break;
                case "image/jpg":
                    $type = "jpg";
                break;
                case "image/png":
                    $type = "png";
                break;
            }

            header("Content-Type: ".$tuple['device_image_type']);
            header("Content-Length: ".$tuple['device_image_size']);
            header('Content-Disposition: inline; filename="device_image.'.$type.'"');
            header("Content-Transfer-Encoding: binary");
            header('Accept-Ranges: bytes'); 
            header('Pragma: no-cache');
            header('Expires: 0');

            echo $tuple['device_image_data'];
        }

        mysqli_free_result($mysql_query);
    }
?>