<?php
    include_once("mysql_connector.php");
    session_start();

    $_SESSION["error"] = array("error_no" => "0000", "error_msj" => "");
    $mysql_reg = null;

    $sql_string = sprintf(
        "call rename_user('%s', '%s', '%s')",
        $_SESSION["token"],
        $_POST['txt_rename_first_name'],
        $_POST['txt_rename_last_name']
    );

    if($mysql_reg = mysqli_query($mysql_connection, $sql_string)){
        $_SESSION["msj"] = "Se ha cambiado tu nombre exitosamente.";
    }else{
        $_SESSION["error"]["error_no"] = "0003";
        $_SESSION["error"]["error_msj"] = "No se pudo cambiar tu nombre debido a un problema con el servidor.";
    }

    unset($_POST['txt_rename_first_name']);
    unset($_POST['txt_rename_last_name']);

    header("location: ".$_SERVER["HTTP_REFERER"]);
    exit();
?>