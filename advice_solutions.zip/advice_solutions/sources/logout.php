<?php
    session_start();
    
    if(isset($_SESSION["token"])){
        unset($_SESSION["token"]);
    }
	
	session_destroy();
    
	header("Cache-Control: no-cache, must-revalidate");
	header("Pragma: no-cache");
	header("Location: ../index.php");
    exit();
?>