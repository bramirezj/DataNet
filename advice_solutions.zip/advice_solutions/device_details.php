<?php
    session_start();
    
    $sql_string = "";

    $device_details = array(
        "id" => "",
        "model" => "N/A",
        "brand" => "N/A",
        "stock" => "N/A",
        "price" => "N/A",
        "processor" => "N/A",
        "ram" => 0,
        "graphic_card" => "N/A",
        "storage" => 0
    );

    if(isset($_GET["device_id"])){
        $sql_string = sprintf("call get_device_details('%s'); call get_device_images_id('%s')", $_GET["device_id"], $_GET["device_id"]);
    }

    include_once("sources/starting_vars.php");

    if($mysql_query = mysqli_store_result($mysql_connection)){
        $tuple = mysqli_fetch_assoc($mysql_query);

        $device_details["id"] = $tuple["id"];
        $device_details["model"] = $tuple["model"];
        $device_details["brand"] = $tuple["brand"];
        $device_details["stock"] = $tuple["stock"];
        $device_details["price"] = $tuple["price"];
        $device_details["processor"] = $tuple["processor"];
        $device_details["ram"] = $tuple["ram"];
        $device_details["graphic_card"] = $tuple["graphic_card"];
        $device_details["storage"] = $tuple["storage"];

        mysqli_free_result($mysql_query);
    }else{
        $error["error_no"] = "0003";
        $error["error_msj"] = "No se pudo cargar toda la información del dispositivo debido a un problema con el servidor.";
    }
?>

<!DOCTYPE html>

<html lang="en-US">
    <head>
        <?php
            include_once("sources/dependencies.php");
            include_once("sources/scripts_fxs.php");
        ?>

        <link rel="stylesheet" type="text/css" href="lib/datatables/css/dataTables.bootstrap4.css" />
        <link rel="stylesheet" type="text/css" href="css/backgrounds_sty.css" />
        <link rel="stylesheet" type="text/css" href="css/store_sty.css" />
        
        <script type="text/javascript" src="lib/datatables/js/jquery.dataTables.js"></script>
        <script type="text/javascript" src="lib/datatables/js/dataTables.bootstrap4.js"></script>
        <script type="text/javascript" src="js/store_src.js"></script>

        <title>, Detalles del dispositivo | Advice & Solutions</title>
    </head>

    <body>
        <header>
            <?php include_once("includes/header.inc"); ?>
        </header>

        <main>
            <?php
                if($on_session){
                    include_once("includes/change_user_image_modal.inc");
                }
            ?>

            <div class="container">
                <div class="row">
                    <div id="top_space" class="col-lg-12"></div>
                </div>

                <div class="row">
                    <div class="col-lg-12">
                        <?php include_once("includes/alerts.inc"); ?>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-12 pb-3">
                        <div class="card border-0 shadow">
                            <div class="card-body">
                                <h4 class="card-title">
                                    <strong>
                                        <?php echo $device_details["model"]; ?>
                                    </strong>
                                </h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>

        <footer>
            <?php include_once("includes/footer.inc"); ?>
        </footer>
    </body>
</html>