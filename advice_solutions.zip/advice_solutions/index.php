<?php
    session_start();
    include_once("sources/starting_vars.php");
?>

<!DOCTYPE html>

<html lang="en-US">
    <head>
        <?php
            include_once("sources/dependencies.php");
            include_once("sources/scripts_fxs.php");
        ?>

        <link rel="stylesheet" type="text/css" href="css/index_sty.css" />

        <title>Advice & Solutions</title>
    </head>

    <body>
        <header>
            <?php include_once("includes/header.inc"); ?>
        </header>

        <main>
            <?php
                if($on_session){
                    include_once("includes/change_user_image_modal.inc");
                }
            ?>
            
            <div class="container-fluid">
                <div class="row">
                    <div id="top_space_index" class="col-lg-12"></div>
                </div>

                <div id="index_image_1" class="row">
                    <div class="col-lg-12 pt-3">
                        <?php include_once("includes/alerts.inc"); ?>

                        <div class="row">
                            <div class="col-lg-6 pt-3 px-5">
                                <h2>
                                    <strong>
                                        Aprende a utilizar las tecnologías de la información hoy mismo
                                    </strong>
                                </h2>

                                <p class="mt-3 mb-5">
                                    Nosotros te ayudaremos durante el proceso de aprendizaje brindándole asistencia y muchos servicios más.
                                </p>
                                
                                <a href="login_frm.php" role="button" class="btn btn-lg btn-warning rounded-pill">
                                    <strong>¡Regístrese con nosotros ahora!</strong>
                                </a>
                            </div>
                            
                            <div class="col-lg-6"></div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-4 text-center px-5 py-5">
                        <i class="fas fa-comment fa-5x text-warning my-3"></i>
                        <p class="mb-3">Te ayudaremos con todo sobre tecnologías de la información cuando sea necesario, en cualquier lgar y momento.</p>
                    </div>
                    
                    <div class="col-lg-4 text-center px-5 py-5">
                        <i class="fas fa-chalkboard-teacher fa-5x text-warning my-3"></i>
                        <p class="mb-3">Aprende y desarrolle tus habilidades en las tecnologías de la información y poder desenvolverte en el área profesional.</p>
                    </div>
                    
                    <div class="col-lg-4 text-center px-5 py-5">
                        <i class="fas fa-laptop fa-5x text-warning my-3"></i>
                        <p class="mb-3">Puedes comprar dispositivos con precios muy accesibles y ajustados según tus necesidades y con soporte.</p>
                    </div>
                </div>
            </div>
        </main>

        <footer>
            <?php include_once("includes/footer.inc"); ?>
        </footer>
    </body>
</html>