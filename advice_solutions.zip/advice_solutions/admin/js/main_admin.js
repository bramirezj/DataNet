function logout(){
    if(confirm("¿Estás seguro de cerrar la sesión?")){
        location.href = "sources/logout.php";
    }
}

function build_popover_tooltip_content(type){
    var content = '';

    switch(type){
        case 0:
            content =
                '<div class="text-center">' +
                    '<button class="btn btn-danger w-100" onclick="logout()">' +
                        '<i class="fas fa-power-off fa-2x my-1"></i>' +
                    '</button>' +
                '</div>';
        break;
    }

    return content;
}

$(document).ready(function(){
    $('#user_info').popover({
        container: '#user_info_pane',
        placement: 'bottom',
        sanitize: false,
        html: true,
        title: 'Cerrar sesión',
        content: build_popover_tooltip_content(0)
    });

    $('#user_info_icon').tooltip({
        container: "#user_info",
        placement: "left"
    });

    $('#user_info_icon').tooltip("show");
    $('#user_info_icon').unbind();

    (function(){
        'use strict';
        window.addEventListener('load', function(){
            Array.prototype.filter.call(document.getElementsByClassName('needs-validation'), function(form){
                if(typeof InstallTrigger === 'undefined'){
                    form.noValidate = true;
                }

                form.addEventListener('submit', function(event){
                    if (form.checkValidity() === false){
                        event.preventDefault();
                        event.stopPropagation();
                    }else{
                        $('.modal').modal('hide');
                    }
    
                    form.classList.add('was-validated');
                }, false);
            });
        }, false);
    })();
});