<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1" />

<link rel="stylesheet" type="text/css" href="../lib/bootstrap/css/bootstrap.css" />
<link rel="stylesheet" type="text/css" href="../lib/fontawesome/css/all.css" />
<link rel="stylesheet" type="text/css" href="../lib/bootstrap_menu/css/bootstrap-menu.css" />
<link rel="stylesheet" type="text/css" href="../lib/bootstrap_colors/bootstrap-colors.css" />
<link rel="stylesheet" type="text/css" href="css/main_admin.css" />
<link rel="icon" type="image/x-icon" href="../favicon.ico" />

<script type="text/javascript" src="../lib/jquery/jquery.min.js"></script>
<script type="text/javascript" src="../lib/popper/popper.min.js"></script>
<script type="text/javascript" src="../lib/bootstrap/js/bootstrap.js"></script>
<script type="text/javascript" src="../lib/fontawesome/js/all.js"></script>
<script type="text/javascript" src="../lib/bootstrap_menu/js/bootstrap-menu.js"></script>
<script type="text/javascript" src="js/main_admin.js"></script>