<?php
    include_once("../sources/mysql_connector.php");

    $error = array("error_no" => "0000", "error_msj" => "");
    $msj = "";
    $user_admin_email = "";
    $on_session_admin = false;

    if(isset($_SESSION["error"]) && ($_SESSION["error"]["error_no"] != "0000")){
        $error["error_no"] = $_SESSION["error"]["error_no"];
        $error["error_msj"] = $_SESSION["error"]["error_msj"];

        unset($_SESSION["error"]);
    }

    if(isset($_SESSION["msj"]) && ($_SESSION["msj"] != "")){
        $msj = $_SESSION["msj"];

        unset($_SESSION["msj"]);
    }
    
    if(isset($_SESSION["token_admin"]) && ($_SESSION["token_admin"] != "")){
        $sql_string = sprintf("call get_user_admin_info('%s'); ", $_SESSION["token_admin"]).$sql_string;

        if(!mysqli_multi_query($mysql_connection, $sql_string) && $error["error_msj"] == ""){
            $error["error_no"] = "0003";
            $error["error_msj"] = "No se pudo cargar la información del usuario debido a un problema con el servidor.";
        }

        if($mysql_query_u = mysqli_store_result($mysql_connection)){
            $user_admin_email = mysqli_fetch_assoc($mysql_query_u)["email"];
            mysqli_free_result($mysql_query_u);
        }

        $on_session_admin = true;
    }
?>