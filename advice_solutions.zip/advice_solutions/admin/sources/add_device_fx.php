<?php
    include_once("../../sources/mysql_connector.php");
    session_start();

    $_SESSION["error"] = array("error_no" => "0000", "error_msj" => "");
    $mysql_query_u = null;
    $mysql_reg_d = null;
    $device_id = "";
    $allowed = false;

    $sql_string_d = sprintf(
        "call check_user_admin('%s'); call add_device('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s');",
        $_SESSION["token_admin"],
        $_POST['txt_add_device_model'],
        $_POST['txt_add_device_brand'],
        $_POST['txt_add_device_stock'],
        $_POST['txt_add_device_price'],
        $_POST['txt_add_device_processor'],
        $_POST['txt_add_device_ram'],
        $_POST['txt_add_device_graphic_card'],
        $_POST['txt_add_device_storage']
    );

    if(!mysqli_multi_query($mysql_connection, $sql_string_d)){
        $error["error_no"] = "0003";
        $error["error_msj"] = "No se pudo guardar la información del dispositivo debido a un problema con el servidor.";
    }

    if($mysql_query_u = mysqli_store_result($mysql_connection)){
        if(mysqli_fetch_assoc($mysql_query_u)["user_admin_exists"] == 1){
            $allowed = true;
        }

        mysqli_free_result($mysql_query_u);
    }

    if($allowed){
        mysqli_next_result($mysql_connection);
        mysqli_next_result($mysql_connection);

        if($mysql_reg_d = mysqli_store_result($mysql_connection)){
            $device_id = mysqli_fetch_assoc($mysql_reg_d)["device_id"];

            mysqli_free_result($mysql_reg_d);
        }
        
        mysqli_next_result($mysql_connection);

        $sql_string_i = "";

        for($i=0; $i < count($_FILES["fl_add_device_images"]["tmp_name"]); $i++){
            $file = $_FILES["fl_add_device_images"]["tmp_name"][$i];
            $size = $_FILES["fl_add_device_images"]["size"][$i];
            $type = $_FILES["fl_add_device_images"]["type"][$i];
            $name = $_FILES["fl_add_device_images"]["name"][$i];

            if($file != "" && $file != null){
                $file_stream = fopen($file, "rb");
                $data = fread($file_stream, $size);
                $data = addslashes($data);
                fclose($file_stream);

                $sql_string_i .= sprintf(
                    "call add_device_images('%s', '%s', '%s', '%s'); ",
                    $device_id,
                    $size,
                    $type,
                    $data
                );
            }
        }

        if(!mysqli_multi_query($mysql_connection, $sql_string_i)){
            $error["error_no"] = "0003";
            $error["error_msj"] = "No se pudo guardar las imágenes del dispositivo debido a un problema con el servidor.";
        }
    }

    unset($_POST['txt_add_device_model']);
    unset($_POST['txt_add_device_brand']);
    unset($_POST['txt_add_device_stock']);
    unset($_POST['txt_add_device_price']);
    unset($_POST['txt_add_device_processor']);
    unset($_POST['txt_add_device_ram']);
    unset($_POST['txt_add_device_graphic_card']);
    unset($_POST['txt_add_device_storage']);
    unset($_FILES['fl_add_device_images']);

    header("location: ".$_SERVER["HTTP_REFERER"]);
    exit();
?>