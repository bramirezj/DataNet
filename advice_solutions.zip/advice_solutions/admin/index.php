<?php
    session_start();
    
    $sql_string = "";

    include_once("sources/starting_vars_admin.php");

    if(!$on_session_admin){
        header("Location: login_admin_frm.php");
        exit();
    }
?>

<!DOCTYPE html>

<html lang="en-US">
    <head>
        <?php
            include_once("sources/dependencies_admin.php");
        ?>

        <link rel="stylesheet" type="text/css" href="../css/login_signup_sty.css" />

        <title>Administración del sitio | Advice & Solutions</title>
    </head>

    <body>
        <header>
            <?php include_once("includes/header_admin.inc"); ?>
        </header>

        <main class="bg-dark">
            <?php
                if($on_session_admin){
                    include_once("includes/add_device_modal.inc");
                    include_once("includes/mod_device_modal.inc");
                }
            ?>

            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 pt-5 pb-2"></div>
                </div>

                <div class="row">
                    <div class="col-lg-12">
                        <button class="btn btn-lg btn-warning" data-toggle="modal" data-target="#add_device_modal">
                            <i class="fas fa-plus mr-1"></i> Agregar equipo
                        </button>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-12">
                        
                    </div>
                </div>
            </div>
        </main>
    </body>
</html>