<?php
    session_start();
    include_once("sources/starting_vars_admin.php");
?>

<!DOCTYPE html>

<html lang="en-US">
    <head>
        <?php
            include_once("sources/dependencies_admin.php");
        ?>
        
        <link rel="stylesheet" type="text/css" href="../css/login_signup_sty.css" />

        <title>Ingreso administración | Advice & Solutions</title>
    </head>

    <body>
        <main class="bg-dark">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-4"></div>

                    <div class="col-lg-4 py-4">
                        <div class="card">
                            <div class="card-body text-center">
                                <img src="../assets/images/icons/logo2.png" width="80" alt="A&S logo" class="mb-4" />

                                <h4 class="mb-3">
                                    <strong>Ingreso</strong>
                                </h4>

                                <?php include_once("includes/alerts_admin.inc"); ?>

                                <form action="sources/login_admin_fx.php" method="post" enctype="application/x-www-form-urlencoded" id="login_admin_frm" name="login_admin_frm" class="needs-validation" autocomplete="off">
                                    <div class="form-group text-left">
                                        <label for="txt_login_admin_username_email">Nombre de usuario o e-Mail</label>

                                        <div class="input-group w-100">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text">
                                                    <i class="fas fa-user"></i>
                                                </span>
                                            </div>

                                            <input type="text" id="txt_login_admin_username_email" name="txt_login_admin_username_email" class="form-control rounded-right" maxlength="100" aria-label="Nombre de usuario o e-Mail" aria-describedby="login-admin-username-email-input" required />
                                            <div class="invalid-feedback">Nombre de usuario o e-Mail requerido</div>
                                        </div>
                                    </div>

                                    <div class="form-group text-left">
                                        <label for="txt_login_admin_password">Contraseña</label>

                                        <div class="input-group w-100">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text">
                                                    <i class="fas fa-key"></i>
                                                </span>
                                            </div>

                                            <input type="password" id="txt_login_admin_password" name="txt_login_admin_password" class="form-control rounded-right" maxlength="50" aria-label="Contraseña" aria-describedby="login-user-admin-password-input" required />
                                            <div class="invalid-feedback">Contraseña requerida</div>
                                        </div>
                                    </div>

                                    <button type="submit" class="btn btn-warning">
                                        <strong>Ingresar</strong>
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-4"></div>
                </div>
            </div>
        </main>
    </body>
</html>