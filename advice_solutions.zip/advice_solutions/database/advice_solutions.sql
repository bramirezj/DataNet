/*=== Database create and use ==================================================================================================*/
create database advice_solutions;
use advice_solutions;

/*=== Tables ==================================================================================================*/
create table users(
	token varchar(8) not null primary key,
    first_name varchar(30) not null,
    last_name varchar(30) not null,
    role tinyint(1) not null,
    username varchar(30) unique not null,
    phone varchar(15) unique not null,
    email varchar(100) unique not null,
    password varchar(50) not null,
    registered timestamp default current_timestamp,
    modified timestamp default current_timestamp on update current_timestamp
)
engine=innodb default
charset=utf8mb4;

create table users_images(
	id int not null auto_increment primary key,
	user varchar(8) unique not null,
    user_image_name varchar(100) not null,
    user_image_size int not null,
    user_image_type varchar(20) not null,
    user_image_data longblob not null,
    registered timestamp default current_timestamp,
    modified timestamp default current_timestamp on update current_timestamp
)
engine=innodb default
charset=utf8mb4;

create table users_admin(
	token varchar(8) not null primary key,
    username varchar(30) unique not null,
    email varchar(100) unique not null,
    password varchar(50) not null,
    registered timestamp default current_timestamp,
    modified timestamp default current_timestamp on update current_timestamp
)
engine=innodb default
charset=utf8mb4;

create table devices(
	id varchar(16) not null primary key,
    model varchar(30) not null,
    brand varchar(20) not null,
    stock smallint not null,
    price float not null,
    processor varchar(50) not null,
    ram tinyint not null,
    graphic_card varchar(30) not null,
    storage smallint not null,
    registered timestamp default current_timestamp,
    modified timestamp default current_timestamp on update current_timestamp
)
engine=innodb default
charset=utf8mb4;

create table devices_images(
	id int not null auto_increment primary key,
    device varchar(16) not null,
    device_image_size int not null,
    device_image_type varchar(20) not null,
    device_image_data longblob not null,
    registered timestamp default current_timestamp,
    modified timestamp default current_timestamp on update current_timestamp
)
engine=innodb default
charset=utf8mb4;
/*
create table shop_cart(
	id varchar(16) not null primary key,
    user varchar(8) not null,
    device varchar(16) not null,
    cantity smallint not null,
    registered timestamp default current_timestamp,
    modified timestamp default current_timestamp on update current_timestamp
)
engine=innodb default
charset=utf8mb4;
*/
/*=== Foreign keys ==================================================================================================*/
alter table users_images add constraint fk_usr_images_users
	foreign key(user)
    references users(token);
    
alter table devices_images add constraint fk_dvc_images_devices
	foreign key(device)
    references devices(id);
/*
alter table shop_cart add constraint fk_shop_cart_users
	foreign key(user)
    references users(token);
    
alter table shop_cart add constraint fk_shop_cart_devices
	foreign key(device)
    references devices(id);
*/
/*=== Views ==================================================================================================*/
create view vw_users(token, first_name, last_name, role, username, phone, email, password)
as
	select token, first_name, last_name, role, username, phone, email, password
    from users;
    
create view vw_users_images(user, user_image_name, user_image_size, user_image_type, user_image_data)
as
	select user, user_image_name, user_image_size, user_image_type, user_image_data
    from users_images;
    
create view vw_users_admin(token, username, email, password)
as
	select token, username, email, password
    from users_admin;

create view vw_devices(id, model, brand, stock, price, processor, ram, graphic_card, storage)
as
	select id, model, brand, stock, price, processor, ram, graphic_card, storage
    from devices;
    
create view vw_devices_images(device, device_image_size, device_image_type, device_image_data)
as
	select device, device_image_size, device_image_type, device_image_data
    from devices_images;
/*
create view vw_shop_cart(id, user, device, cantity)
as
	select id, user, device, cantity
    from shop_cart;
*/
/*=== Functions ==================================================================================================*/
delimiter //
create function generate_token()
	returns varchar(8) deterministic
begin
	declare generated_token varchar(8);

	set generated_token = rpad(
		cast(
			hex(
				(timestampdiff(
					second, '1970-01-01 00:00:00', curtime()
				) * round(
					rand() * 1000, 0
				)
			) / 1000) as char
		), 8, '0'
	);

	return generated_token;
end
// delimiter

delimiter // 
create function generate_id_no()
	returns varchar(16) deterministic
begin
	declare generated_id_no varchar(16);
    
    set generated_id_no = (
		select lpad(
			timestampdiff(
				second, '1970-01-01 00:00:00', curtime()
			) * floor(
				rand() * 999999.99
			), 16, '0'
		) as id_no
    );
    
    return generated_id_no;
end
// delimiter

/*=== Procedures ==================================================================================================*/
delimiter //
create procedure login(
	in p_username_email varchar(100),
    in p_password varchar(50)
)begin
	select token
    from vw_users
    where ((username = p_username_email) or (email = p_username_email)) and (password = md5(p_password));
end
// delimiter

delimiter //
create procedure signup(
	in p_first_name varchar(30),
    in p_last_name varchar(30),
    in p_role tinyint(1),
	in p_username varchar(30),
    in p_phone varchar(15),
    in p_email varchar(100),
    in p_password varchar(50)
)begin
	declare p_token varchar(8);
	set p_token = generate_token();
    
    insert
		into vw_users(token, first_name, last_name, role, username, phone, email, password)
        values(p_token, p_first_name, p_last_name, p_role, p_username, p_phone, p_email, md5(p_password));
        
	select p_token as token;
end
// delimiter

delimiter //
create procedure rename_user(
	in p_token varchar(8),
	in p_first_name varchar(30),
    in p_last_name varchar(30)
)begin
	update vw_users
    set first_name = p_first_name, last_name = p_last_name
    where (token = p_token);
end
// delimiter

delimiter //
create procedure change_user_role(
	in p_token varchar(8),
	in p_role tinyint(1)
)begin
	update vw_users
    set role = p_role
    where (token = p_token);
end
// delimiter

delimiter //
create procedure edit_user_phone(
	in p_token varchar(8),
	in p_phone varchar(15)
)begin
	update vw_users
    set phone = p_phone
    where (token = p_token);
end
// delimiter

delimiter //
create procedure edit_user_email(
	in p_token varchar(8),
    in p_email varchar(100)
)begin
	update vw_users
    set email = p_email
    where (token = p_token);
end
// delimiter

delimiter //
create procedure change_user_password(
	in p_token varchar(8),
    in p_current_password varchar(50),
    in p_new_password varchar(50)
)begin
	declare is_password_changed bool;
	set is_password_changed = false;
    
    if(exists(select token from vw_users where ((token = p_token) and (password = md5(p_current_password)))) and (p_new_password != ''))
    then
		update vw_users
        set password = md5(p_new_password)
        where (token = p_token);
        
        set is_password_changed = true;
    end if;
    
    select is_password_changed;
end
// delimiter

delimiter //
create procedure get_user_info(
	in p_token varchar(8)
)begin
	select u.first_name, u.last_name, u.email, ui.user_image_exists
    from vw_users u
    inner join(
		select count(i.user) as user_image_exists
		from vw_users_images i
		where (i.user = p_token)
    ) as ui
    where (token = p_token);
end
// delimiter

delimiter //
create procedure get_user_details(
	in p_token varchar(8)
)begin
	select role, phone
    from vw_users
    where (token = p_token);
end
// delimiter

delimiter //
create procedure change_user_image(
	in p_user varchar(8),
    in p_user_image_name varchar(100),
    in p_user_image_size int,
    in p_user_image_type varchar(20),
    in p_user_image_data longblob
)begin
	if exists(select user from vw_users_images where (user = p_user))
    then
		update vw_users_images
        set
			user_image_name = p_user_image_name,
            user_image_size = p_user_image_size,
            user_image_type = p_user_image_type,
            user_image_data = p_user_image_data
        where (user = p_user);
    else
		insert
			into vw_users_images(user, user_image_name, user_image_size, user_image_type, user_image_data)
            values(p_user, p_user_image_name, p_user_image_size, p_user_image_type, p_user_image_data);
    end if;
end
// delimiter

delimiter //
create procedure remove_user_image(
	in p_user varchar(8)
)begin
	delete
		from vw_users_images
        where (user = p_user);
end
// delimiter

delimiter //
create procedure get_user_image(
	in p_user varchar(8)
)begin
	select user_image_name, user_image_size, user_image_type, user_image_data
    from vw_users_images
    where (user = p_user);
end
// delimiter

delimiter //
create procedure login_admin(
	in p_username_email varchar(100),
    in p_password varchar(50)
)begin
	select token as token_admin
    from vw_users_admin
    where ((username = p_username_email) or (email = p_username_email)) and (password = md5(p_password));
end
// delimiter

delimiter //
create procedure signup_admin(
	in p_username varchar(30),
    in p_email varchar(100),
    in p_password varchar(50)
)begin
	declare p_token varchar(8);
	set p_token = generate_token();
    
    insert
		into vw_users_admin(token, username, email, password)
        values(p_token, p_username, p_email, md5(p_password));
end
// delimiter

delimiter //
create procedure get_user_admin_info(
	in p_token varchar(8)
)begin
	select email
    from vw_users_admin
    where (token = p_token);
end
// delimiter

delimiter //
create procedure check_user_admin(
	in p_token varchar(8)
)begin
	declare user_admin_exists bool;
    set user_admin_exists = false;
    
    if(exists(select token from users_admin where (token = p_token)))
    then
		set user_admin_exists = true;
    end if;
    
    select user_admin_exists;
end
// delimiter

delimiter //
create procedure add_device(
	in p_model varchar(30),
    in p_brand varchar(20),
    in p_stock smallint,
    in p_price float,
    in p_processor varchar(50),
    in p_ram tinyint,
    in p_graphic_card varchar(30),
    in p_storage smallint
)begin
	declare p_id varchar(16);
	set p_id = generate_id_no();
	
	insert
		into vw_devices(id, model, brand, stock, price, processor, ram, graphic_card, storage)
		values(p_id, p_model, p_brand, p_stock, p_price, p_processor, p_ram, p_graphic_card, p_storage);
    
    select p_id as device_id;
end
// delimiter

delimiter //
create procedure add_device_images(
	in p_id varchar(16),
    in p_device_image_size int,
    in p_device_image_type varchar(20),
    in p_device_image_data longblob
)begin
	insert
		into vw_devices_images(device, device_image_size, device_image_type, device_image_data)
		values(p_id, p_device_image_size, p_device_image_type, p_device_image_data);
end
// delimiter

delimiter //
create procedure get_device_image(
	in p_id varchar(16),
    in p_first_only bool
)begin
	if(p_first_only)
    then
		select device_image_size, device_image_type, device_image_data
		from vw_devices_images
		where (device = p_id)
		limit 1;
    else
		select device_image_size, device_image_type, device_image_data
		from vw_devices_images
		where (device = p_id);
    end if;
end
// delimiter
/*
delimiter //
create procedure add_to_shop_cart(
	in p_user varchar(8),
    in p_device varchar(16),
    in p_cantity smallint
)begin
	declare p_id varchar(16);
	set p_id = generate_id_no();
    
    insert
		into vw_shop_cart(id, user, device, cantity)
        values(p_id, p_user, p_device, p_cantity);
end
// delimiter

delimiter //
create procedure remove_to_shop_cart(

)begin

end
// delimiter
*/
delimiter //