<?php
    session_start();

    $sql_string = sprintf("call get_user_details('%s');", $_SESSION["token"]);
    $user_details = array("role" => "0", "phone" => "N/A");
    
    include_once("sources/starting_vars.php");

    if($on_session){
        mysqli_next_result($mysql_connection);
        mysqli_next_result($mysql_connection);

        if($mysql_query_d = mysqli_store_result($mysql_connection)){
            $tuple_d = mysqli_fetch_assoc($mysql_query_d);

            $user_details["role"] = $tuple_d["role"];
            $user_details["phone"] = $tuple_d["phone"];

            mysqli_free_result($mysql_query_d);
        }
    }else{
        header("Location: index.php");
        exit();
    }
?>

<!DOCTYPE html>

<html lang="en-US">
    <head>
        <?php
            include_once("sources/dependencies.php");
            include_once("sources/scripts_fxs.php");
        ?>

        <link rel="stylesheet" type="text/css" href="css/backgrounds_sty.css" />
        <link rel="stylesheet" type="text/css" href="css/user_details_sty.css" />

        <script type="text/javascript" src="js/user_details_src.js"></script>
        
        <title>Perfil de usuario | Advice & Solutions</title>
    </head>

    <body>
        <header>
            <?php include_once("includes/header.inc"); ?>
        </header>

        <main>
            <?php
                if($on_session){
                    include_once("includes/change_user_image_modal.inc");
                }
            ?>

            <div class="container">
                <div class="row">
                    <div id="top_space" class="col-lg-12"></div>
                </div>

                <div class="row">
                    <div class="col-lg-12">
                        <?php include_once("includes/alerts.inc"); ?>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-12 pb-3">
                        <div class="card border-0 shadow">
                            <div class="card-header bg-secondary text-light border-bottom border-light pt-2">
                                <div class="row">
                                    <div class="col-1 pb-1 pl-1">
                                        <a href="user_window.php" class="text-light" title="Volver al panel principal">
                                            <i class="fas fa-arrow-alt-circle-left fa-2x mr-1"></i>
                                        </a>
                                    </div>
                                    
                                    <div class="col-10 text-center pt-0 pb-1">
                                        <h5 class="card-title mb-0">
                                            <strong>Perfil de usuario</strong>
                                        </h5>
                                    </div>
                                    
                                    <div class="col-1 pb-1"></div>
                                </div>

                                <ul class="nav nav-tabs card-header-tabs" id="user_details_tabs" role="tablist">
                                    <li class="nav-item">
                                        <a class="nav-link text-light active" id="user_details_general_tab" data-toggle="tab" href="#user_details_general" role="tab" aria-controls="user_details_general" aria-selected="true">
                                            <i class="fas fa-address-card text-grape mr-2"></i>
                                            <strong>General</strong>
                                        </a>
                                    </li>

                                    <li class="nav-item">
                                        <a class="nav-link text-light" id="user_details_security_tab" data-toggle="tab" href="#user_details_security" role="tab" aria-controls="user_details_security" aria-selected="false">
                                            <i class="fas fa-lock text-grape mr-2"></i>
                                            <strong>Seguridad</strong>
                                        </a>
                                    </li>
                                </ul>
                            </div>

                            <div class="card-body">
                                <div class="tab-content" id="user_details_content">
                                    <div class="tab-pane fade show active" id="user_details_general" role="tabpanel" aria-labelledby="user_details_general_tab">
                                        <div class="row">
                                            <div class="col-lg-5 text-center pt-4">
                                                <img src="sources/get_user_image.php" id="user_details_image" class="rounded-circle" alt="Imagen de perfil" title="Imagen de perfil" />
                                                <br />

                                                <button type="button" class="btn btn-sm btn-grape rounded-pill my-3" data-toggle="modal" data-target="#change_user_image_modal">
                                                    <i class="fas fa-camera mr-1"></i>Cambiar imagen
                                                </button>
                                            </div>

                                            <div id="user_details_general_pane" class="col-lg-7 pt-3">
                                                <h5 class="mb-3">
                                                    <strong>General</strong>
                                                </h5>

                                                <h6>
                                                    <i class="fas fa-tag text-warning mr-1"></i>
                                                    <strong>Nombre</strong>
                                                </h6>

                                                <p>
                                                    <?php echo $user_info["first_name"]." ".$user_info["last_name"]; ?>

                                                    <a class="text-secondary ml-1" data-toggle="collapse" href="#rename_user_collapse" title="Renombrar">
                                                        <i class="fas fa-pencil-alt"></i>
                                                    </a>
                                                </p>

                                                <div class="collapse" id="rename_user_collapse" data-parent="#user_details_general_pane">
                                                    <form action="sources/rename_user_fx.php" method="post" enctype="application/x-www-form-urlencoded" id="rename_user_frm" name="rename_user_frm" class="needs-validation" autocomplete="off">
                                                        <label for="txt_rename_first_name">
                                                            <strong>Renombrar</strong>
                                                        </label>

                                                        <div class="form-row">
                                                            <div class="col-lg-6">
                                                                <div class="form-group">
                                                                    <input type="text" id="txt_rename_first_name" name="txt_rename_first_name" class="form-control border-top-0 border-left-0 border-right-0 border-bottom border-secondary rounded-0" maxlength="30" placeholder="Ingresar nombre" title="Ingresar nombre" aria-label="Ingresar nombre" aria-describedby="rename-first-name-input" value="<?php echo $user_info["first_name"]; ?>" required />
                                                                    
                                                                    <div class="valid-feedback">
                                                                        Correcto!<i class="fas fa-thumbs-up ml-1"></i>
                                                                    </div>
                                                            
                                                                    <div class="invalid-feedback">Nombre requerido</div>
                                                                </div>
                                                            </div>

                                                            <div class="col-lg-6">
                                                                <div class="form-group">
                                                                    <input type="text" id="txt_rename_last_name" name="txt_rename_last_name" class="form-control border-top-0 border-left-0 border-right-0 border-bottom border-secondary rounded-0" maxlength="30" placeholder="Ingresar apellidos" title="Ingresar apellidos" aria-label="Ingresar apellidos" aria-describedby="rename-last-name-input" value="<?php echo $user_info["last_name"]; ?>" required />
                                                                    
                                                                    <div class="valid-feedback">
                                                                        Correcto!<i class="fas fa-thumbs-up ml-1"></i>
                                                                    </div>
                                                            
                                                                    <div class="invalid-feedback">Apellidos requerido</div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                            
                                                        <input type="submit" class="btn btn-warning rounded-pill" value="Editar" />
                                                        <input type="reset" class="btn btn-dark rounded-pill" data-toggle="collapse" data-target="#rename_user_collapse" value="Cancelar" />
                                                    </form>
                                                </div>

                                                <hr />

                                                <h6>
                                                    <i class="fas fa-briefcase text-warning mr-1"></i>
                                                    <strong>Rol</strong>
                                                </h6>

                                                <p>
                                                    <?php
                                                        switch($user_details["role"]){
                                                            case 0: echo "Usuario normal"; break;
                                                            case 1: echo "Docente"; break;
                                                            case 2: echo "Estudiante"; break;
                                                            case 3: echo "Desarrollador"; break;
                                                            case 4: echo "Pequeño empresario"; break;
                                                            case 5: echo "Gran empresario"; break;
                                                        }
                                                    ?>

                                                    <a class="text-secondary ml-1" data-toggle="collapse" href="#change_user_role_collapse" title="Cambiar rol">
                                                        <i class="fas fa-pencil-alt"></i>
                                                    </a>

                                                    <br />

                                                    <small class="text-muted">Los roles permiten personalizar tu experiencia para que se adapte mejor a tus necesidades.</small>
                                                </p>

                                                <div class="collapse" id="change_user_role_collapse" data-parent="#user_details_general_pane">
                                                    <form action="sources/change_user_role_fx.php" method="post" enctype="application/x-www-form-urlencoded" id="change_user_role_frm" name="change_user_role_frm" class="needs-validation">
                                                        <label for="sel_change_user_role">
                                                            <strong>Cambiar rol</strong>
                                                        </label>

                                                        <div class="form-group">
                                                            <select name="sel_change_user_role" id="sel_change_user_role" class="custom-select border-top-0 border-left-0 border-right-0 border-bottom border-secondary rounded-0">
                                                                <option value="0" <?php echo ($user_details["role"] == 0) ? "selected" : ""; ?>>Usuario normal</option>
                                                                <option value="1" <?php echo ($user_details["role"] == 1) ? "selected" : ""; ?>>Docente</option>
                                                                <option value="2" <?php echo ($user_details["role"] == 2) ? "selected" : ""; ?>>Estudiante</option>
                                                                <option value="3" <?php echo ($user_details["role"] == 3) ? "selected" : ""; ?>>Desarrollador</option>
                                                                <option value="4" <?php echo ($user_details["role"] == 4) ? "selected" : ""; ?>>Pequeño empresario</option>
                                                                <option value="5" <?php echo ($user_details["role"] == 5) ? "selected" : ""; ?>>Gran empresario</option>
                                                            </select>
                                                        </div>
                                                                
                                                        <input type="submit" class="btn btn-warning rounded-pill" value="Editar" />
                                                        <input type="reset" class="btn btn-dark rounded-pill" data-toggle="collapse" data-target="#change_user_role_collapse" value="Cancelar" />
                                                    </form>
                                                </div>

                                                <hr />

                                                <h6>
                                                    <i class="fas fa-phone text-warning mr-1"></i>
                                                    <strong>Número de teléfono</strong>
                                                </h6>

                                                <p>
                                                    <?php echo $user_details["phone"]; ?>

                                                    <a class="text-secondary ml-1" data-toggle="collapse" href="#edit_user_phone_collapse" title="Editar número de teléfono">
                                                        <i class="fas fa-pencil-alt"></i>
                                                    </a>
                                                </p>
                                                
                                                <div class="collapse" id="edit_user_phone_collapse" data-parent="#user_details_general_pane">
                                                    <form action="sources/edit_user_phone_fx.php" method="post" enctype="application/x-www-form-urlencoded" id="edit_user_phone_frm" name="edit_user_phone_frm" class="needs-validation" autocomplete="off">
                                                        <label for="txt_edit_phone">
                                                            <strong>Editar número de teléfono</strong>
                                                        </label>

                                                        <div class="form-group">
                                                            <input type="tel" id="txt_edit_phone" name="txt_edit_phone" class="form-control border-top-0 border-left-0 border-right-0 border-bottom rounded-0 <?php echo ($error["error_no"] == "1062") ? 'border-danger' : 'border-secondary'; ?>" maxlength="9" pattern="[0-9]{4}-[0-9]{4}" placeholder="Ingresar número de teléfono" aria-label="Ingresar número de teléfono" aria-describedby="edit-phone-input" value="<?php echo $user_details["phone"]; ?>" required oninput="check_phone(this)" />
                                                            
                                                            <div class="valid-feedback">
                                                                Correcto!<i class="fas fa-thumbs-up ml-1"></i>
                                                            </div>
                                                    
                                                            <div class="invalid-feedback">
                                                                Número de teléfono completo requerido
                                                            </div>
                                                        </div>
                                                                
                                                        <input type="submit" class="btn btn-warning rounded-pill" value="Editar" />
                                                        <input type="reset" class="btn btn-dark rounded-pill" data-toggle="collapse" data-target="#edit_user_phone_collapse" value="Cancelar" />
                                                    </form>
                                                </div>

                                                <hr />

                                                <h6>
                                                    <i class="fas fa-envelope text-warning mr-1"></i>
                                                    <strong>e-Mail</strong>
                                                </h6>

                                                <p>
                                                    <?php echo $user_info["email"]; ?>

                                                    <a class="text-secondary ml-1" data-toggle="collapse" href="#edit_user_email_collapse" title="Editar e-Mail">
                                                        <i class="fas fa-pencil-alt"></i>
                                                    </a>
                                                </p>

                                                <div class="collapse" id="edit_user_email_collapse" data-parent="#user_details_general_pane">
                                                    <form action="sources/edit_user_email_fx.php" method="post" enctype="application/x-www-form-urlencoded" id="edit_user_email_frm" name="edit_user_email_frm" class="needs-validation" autocomplete="off">
                                                        <label for="txt_edit_email">
                                                            <strong>Editar e-Mail</strong>
                                                        </label>

                                                        <div class="form-group">
                                                            <input type="email" id="txt_edit_email" name="txt_edit_email" class="form-control border-top-0 border-left-0 border-right-0 border-bottom rounded-0 <?php echo ($error["error_no"] == "1062") ? 'border-danger' : 'border-secondary'; ?>" maxlength="100" placeholder="Ingresar e-Mail" aria-label="Ingresar e-Mail" aria-describedby="edit-email-input" value="<?php echo $user_info["email"]; ?>" required />
                                                            
                                                            <div class="valid-feedback">
                                                                Correcto!<i class="fas fa-thumbs-up ml-1"></i>
                                                            </div>
                                                    
                                                            <div class="invalid-feedback">
                                                                e-Mail requerido, debe cumplir con el formato solicitado
                                                            </div>

                                                            <small class="text-muted">
                                                                El e-Mail debe estar en formato <em>example@email.com</em>.
                                                            </small>
                                                        </div>

                                                        <input type="submit" class="btn btn-warning rounded-pill" value="Editar" />
                                                        <input type="reset" class="btn btn-dark rounded-pill" data-toggle="collapse" data-target="#edit_user_email_collapse" value="Cancelar" />
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="tab-pane fade pt-3" id="user_details_security" role="tabpanel" aria-labelledby="user_details_security_tab">
                                        <h5 class="mb-3">
                                            <strong>Seguridad</strong>
                                        </h5>

                                        <h6>
                                            <i class="fas fa-key text-warning mr-1"></i>
                                            <strong>Contraseñas</strong>
                                        </h6>

                                        <p class="text-justify">La contraseña resguarda tu información personal. Se recomienda que sea de 8 caracteres como mínimo y que por lo menos tenga mayúsculas, minúsculas, números, símbolos, o cualquier caracter alfanumérico para que la contraseña sea fuertemente segura.</p>
                                        
                                        <form action="sources/change_user_password_fx.php" method="post" enctype="application/x-www-form-urlencoded" id="change_user_password_frm" name="change_user_password_frm" class="needs-validation">
                                            <label for="txt_edit_email">
                                                <strong>Cambiar contraseña</strong>
                                            </label>

                                            <div class="form-row">
                                                <div class="col-lg-4">    
                                                    <div class="form-group">
                                                        <input type="password" id="txt_change_current_password" name="txt_change_current_password" class="form-control border-top-0 border-left-0 border-right-0 border-bottom rounded-0 <?php echo (($error["error_no"] == "0001") || ($error["error_no"] == "0002")) ? 'border-danger' : 'border-secondary'; ?>" maxlength="50" placeholder="Contraseña actual" aria-label="Contraseña actual" aria-describedby="change-current-password-input" required />
                                                    
                                                        <div class="valid-feedback">
                                                            Correcto!<i class="fas fa-thumbs-up ml-1"></i>
                                                        </div>
                                                
                                                        <div class="invalid-feedback">Contraseña actual requerida</div>
                                                    </div>
                                                </div>

                                                <div class="col-lg-4">
                                                    <div class="form-group">
                                                        <input type="password" id="txt_change_new_password" name="txt_change_new_password" class="form-control border-top-0 border-left-0 border-right-0 border-bottom rounded-0 <?php echo ($error["error_no"] == "0002") ? 'border-danger' : 'border-secondary'; ?>" maxlength="50" minlength="8" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" placeholder="Nueva contraseña" aria-label="Nueva contraseña" aria-describedby="change-new-password-input" required />
                                                        
                                                        <div class="valid-feedback">
                                                            Correcto!<i class="fas fa-thumbs-up ml-1"></i>
                                                        </div>
                                                        
                                                        <div class="invalid-feedback">Nueva contraseña requerida, debe cumplir con el formato solicitado</div>
                                                    </div>
                                                </div>

                                                <div class="col-lg-4">
                                                    <div class="form-group">
                                                        <input type="password" id="txt_change_repeat_password" name="txt_change_repeat_password" class="form-control border-top-0 border-left-0 border-right-0 border-bottom rounded-0 <?php echo ($error["error_no"] == "0002") ? 'border-danger' : 'border-secondary'; ?>" maxlength="50" placeholder="Repetir contraseña" aria-label="Repetir contraseña" aria-describedby="change-repeat-password-input" required />
                                                        
                                                        <div class="valid-feedback">
                                                            Correcto!<i class="fas fa-thumbs-up ml-1"></i>
                                                        </div>
                                                        
                                                        <div class="invalid-feedback">Repetir nueva contraseña requerido</div>
                                                    </div>
                                                </div>
                                            </div>

                                            <input type="submit" class="btn btn-warning rounded-pill" value="Guardar" />
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>

        <footer>
            <?php include_once("includes/footer.inc"); ?>
        </footer>
    </body>
</html>