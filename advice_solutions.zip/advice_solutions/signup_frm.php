<?php
    session_start();
    include_once("sources/starting_vars.php");
?>

<!DOCTYPE html>

<html lang="en-US">
    <head>
        <?php
            include_once("sources/dependencies.php");
        ?>

        <link rel="stylesheet" type="text/css" href="css/backgrounds_sty.css" />
        <link rel="stylesheet" type="text/css" href="css/login_signup_sty.css" />

        <title>Registrarse | Advice & Solutions</title>
    </head>

    <body>
        <main>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-2"></div>
                    
                    <div class="col-lg-8 py-4">
                        <div class="card border-0 shadow">
                            <div class="card-body text-center p-4">
                                <div class="text-left">
                                    <a href="index.php" class="text-secondary" title="Volver">
                                        <i class="fas fa-arrow-alt-circle-left fa-2x mr-1"></i>
                                    </a>
                                </div>

                                <img src="assets/images/icons/logo2.png" width="80" alt="A&S logo" class="mb-4" />

                                <h3 class="mb-3">
                                    <strong>Registro</strong>
                                </h3>

                                <?php include_once("includes/alerts.inc"); ?>

                                <form action="sources/signup_fx.php" method="post" enctype="application/x-www-form-urlencoded" id="signup_frm" name="signup_frm" class="needs-validation" autocomplete="off">
                                    <div class="form-row text-left">
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <div class="input-group w-100 pb-1">
                                                    <div class="input-group-prepend border-bottom border-secondary pt-2 px-2">
                                                        <i class="fas fa-pencil-alt text-secondary"></i>
                                                    </div>

                                                    <input type="text" id="txt_signup_first_name" name="txt_signup_first_name" class="form-control border-top-0 border-left-0 border-right-0 border-bottom border-secondary" maxlength="30" placeholder="Nombre" aria-label="Nombre" aria-describedby="signup-first-name-input" required />
                                                    
                                                    <div class="valid-feedback">
                                                        Correcto!<i class="fas fa-thumbs-up ml-1"></i>
                                                    </div>
                                                    
                                                    <div class="invalid-feedback">Nombre requerido</div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <div class="input-group w-100 pb-1">
                                                    <div class="input-group-prepend border-bottom border-secondary pt-2 px-2">
                                                        <i class="fas fa-pencil-alt text-secondary"></i>
                                                    </div>

                                                    <input type="text" id="txt_signup_last_name" name="txt_signup_last_name" class="form-control border-top-0 border-left-0 border-right-0 border-bottom border-secondary" maxlength="30" placeholder="Apellidos" aria-label="Apellidos" aria-describedby="signup-last-name-input" required />
                                                    
                                                    <div class="valid-feedback">
                                                        Correcto!<i class="fas fa-thumbs-up ml-1"></i>
                                                    </div>

                                                    <div class="invalid-feedback">Apellidos requerido</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                
                                    <div class="form-row">
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <div class="input-group w-100 pb-1">
                                                    <div class="input-group-prepend border-bottom border-secondary text-secondary pt-1 pl-2">
                                                        <i class="fas fa-briefcase mt-1"></i>
                                                        <span class="pl-1 ml-3">Rol:</span>
                                                    </div>

                                                    <select name="sel_signup_user_role" id="sel_signup_user_role" class="custom-select border-top-0 border-left-0 border-right-0 border-bottom border-secondary rounded-0 pt-0">
                                                        <option value="0" selected>Usuario normal</option>
                                                        <option value="1">Docente</option>
                                                        <option value="2">Estudiante</option>
                                                        <option value="3">Desarrollador</option>
                                                        <option value="4">Pequeño empresario</option>
                                                        <option value="5">Gran empresario</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="form-group text-left">
                                                <div class="input-group w-100 pb-1">
                                                    <div class="input-group-prepend border-bottom <?php echo ($error["error_no"] == "1062") ? 'border-danger' : 'border-secondary'; ?> pt-2 px-2">
                                                        <i class="fas fa-user <?php echo ($error["error_no"] == "1062") ? 'text-danger' : 'text-secondary'; ?>"></i>
                                                    </div>

                                                    <input type="text" id="txt_signup_username" name="txt_signup_username" class="form-control border-top-0 border-left-0 border-right-0 border-bottom <?php echo ($error["error_no"] == "1062") ? 'border-danger' : 'border-secondary'; ?>" maxlength="30" placeholder="Nombre de usuario" aria-label="Nombre de usuario" aria-describedby="signup-username-input" required />
                                                    
                                                    <div class="valid-feedback">
                                                        Correcto!<i class="fas fa-thumbs-up ml-1"></i>
                                                    </div>
                                                    
                                                    <div class="invalid-feedback">Nombre de usuario requerido</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-row text-left">
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <div class="input-group w-100 pb-1">
                                                    <div class="input-group-prepend border-bottom <?php echo ($error["error_no"] == "1062") ? 'border-danger' : 'border-secondary'; ?> pt-2 px-2">
                                                        <i class="fas fa-phone <?php echo ($error["error_no"] == "1062") ? 'text-danger' : 'text-secondary'; ?>"></i>
                                                    </div>

                                                    <input type="tel" id="txt_signup_phone" name="txt_signup_phone" class="form-control border-top-0 border-left-0 border-right-0 border-bottom <?php echo ($error["error_no"] == "1062") ? 'border-danger' : 'border-secondary'; ?>" maxlength="9" pattern="[0-9]{4}-[0-9]{4}" placeholder="Número de teléfono" aria-label="Número de teléfono" aria-describedby="signup-phone-input" required oninput="check_phone(this)" />
                                                    
                                                    <div class="valid-feedback">
                                                        Correcto!<i class="fas fa-thumbs-up ml-1"></i>
                                                    </div>
                                                    
                                                    <div class="invalid-feedback">
                                                        Número de teléfono completo requerido
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <div class="input-group w-100 pb-1">
                                                    <div class="input-group-prepend border-bottom <?php echo ($error["error_no"] == "1062") ? 'border-danger' : 'border-secondary'; ?> pt-2 px-2">
                                                        <i class="fas fa-envelope <?php echo ($error["error_no"] == "1062") ? 'text-danger' : 'text-secondary'; ?>"></i>
                                                    </div>

                                                    <input type="email" id="txt_signup_email" name="txt_signup_email" class="form-control border-top-0 border-left-0 border-right-0 border-bottom <?php echo ($error["error_no"] == "1062") ? 'border-danger' : 'border-secondary'; ?>" maxlength="100" placeholder="e-Mail" aria-label="e-Mail" aria-describedby="signup-email-input" required />
                                                    
                                                    <div class="valid-feedback">
                                                        Correcto!<i class="fas fa-thumbs-up ml-1"></i>
                                                    </div>
                                                    
                                                    <div class="invalid-feedback">
                                                        e-Mail requerido, debe cumplir con el formato solicitado
                                                    </div>
                                                </div>

                                                <small class="text-muted">
                                                    El e-Mail debe estar en formato <em>example@email.com</em>.
                                                </small>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-row text-left">
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <div class="input-group w-100 pb-1">
                                                    <div class="input-group-prepend border-bottom <?php echo ($error["error_no"] == "0002") ? 'border-danger' : 'border-secondary'; ?> pt-2 px-2">
                                                        <i class="fas fa-key <?php echo ($error["error_no"] == "0002") ? 'text-danger' : 'text-secondary'; ?>"></i>
                                                    </div>

                                                    <input type="password" id="txt_signup_new_password" name="txt_signup_new_password" class="form-control border-top-0 border-left-0 border-right-0 border-bottom <?php echo ($error["error_no"] == "0002") ? 'border-danger' : 'border-secondary'; ?>" maxlength="50" minlength="8" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" placeholder="Nueva contraseña" aria-label="Nueva contraseña" aria-describedby="signup-new-password-input" required />
                                                    
                                                    <div class="valid-feedback">
                                                        Correcto!<i class="fas fa-thumbs-up ml-1"></i>
                                                    </div>
                                                    
                                                    <div class="invalid-feedback">Nueva contraseña requerida, debe cumplir con el formato solicitado</div>
                                                </div>

                                                <small class="text-muted">Se recomienda que la contraseña sea de 8 caracteres y que tenga mayúsculas, minúsculas, números y símbolos para crear una contraseña fuertemente segura.</small>
                                            </div>
                                        </div>
                                        
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <div class="input-group w-100 pb-1">
                                                    <div class="input-group-prepend border-bottom <?php echo ($error["error_no"] == "0002") ? 'border-danger' : 'border-secondary'; ?> pt-2 px-2">
                                                        <i class="fas fa-key <?php echo ($error["error_no"] == "0002") ? 'text-danger' : 'text-secondary'; ?>"></i>
                                                    </div>

                                                    <input type="password" id="txt_signup_repeat_password" name="txt_signup_repeat_password" class="form-control border-top-0 border-left-0 border-right-0 border-bottom <?php echo ($error["error_no"] == "0002") ? 'border-danger' : 'border-secondary'; ?>" maxlength="50" placeholder="Repetir contraseña" aria-label="Repetir contraseña" aria-describedby="signup-repeat-password-input" required />
                                                    
                                                    <div class="valid-feedback">
                                                        Correcto!<i class="fas fa-thumbs-up ml-1"></i>
                                                    </div>
                                                    
                                                    <div class="invalid-feedback">Repetir nueva contraseña requerido</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group py-3">
                                        <button type="submit" class="btn btn-dark rounded-pill w-50">
                                            <strong>Registrarse</strong>
                                        </button>
                                    </div>
                                </form>

                                <small>O puede registrarse utilizando</small>
                                
                                <div id="social_network_accounts_pane" class="pt-2 pb-4">
                                    <a href="" title="Cuenta de Facebook">
                                        <img src="assets/images/icons/facebook.png" height="32" width="32" alt="Facebook account" />
                                    </a>

                                    <a href="" class="mx-1" title="Cuenta de Twitter">
                                        <img src="assets/images/icons/twitter.png" height="32" width="32" alt="Twitter account" />
                                    </a>

                                    <a href="" title="Cuenta de Google">
                                        <img src="assets/images/icons/google.png" height="32" width="32" alt="Google account" />
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-2"></div>
                </div>
            </div>
        </main>
    </body>
</html>