<?php
    session_start();
    
    $sql_string = "";

    include_once("sources/starting_vars.php");

    if(!$on_session){
        header("Location: index.php");
        exit();
    }
?>

<!DOCTYPE html>

<html lang="en-US">
    <head>
        <?php
            include_once("sources/dependencies.php");
            include_once("sources/scripts_fxs.php");
        ?>

        <link rel="stylesheet" type="text/css" href="css/backgrounds_sty.css" />
        <link rel="stylesheet" type="text/css" href="css/user_window_sty.css" />
        
        <title>Página principal de usuario | Advice & Solutions</title>
    </head>

    <body>
        <header>
            <?php include_once("includes/header.inc"); ?>
        </header>

        <main>
            <?php
                if($on_session){
                    include_once("includes/change_user_image_modal.inc");
                }
            ?>

            <div class="container-fluid">
                <div class="row">
                    <div id="top_space" class="col-lg-12"></div>
                </div>

                <div class="row">
                    <div class="col-lg-12">
                        <?php include_once("includes/alerts.inc"); ?>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-12 pb-3">
                        <div class="bg-secondary text-light text-center rounded shadow pt-1 pb-1">
                            <h5 class="mb-0">
                                <strong>Panel principal de usuario</strong>
                            </h5>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-lg-4 pb-3">
                        <div class="card border-0 shadow h-100">
                            <img class="card-img-top" src="assets/images/thumbnails/thumb_01.jpg" alt="Img 01" />

                            <div class="card-body h-75">
                                <h5 class="card-title">
                                    <strong>Asesoría y asistencia al usuario</strong>
                                </h5>

                                <p class="card-text">Puedes buscar asistencia cuando lo necesites en cualquier momento y lugar.</p>
                            </div>

                            <div class="card-body text-center h-25">
                                <a href="advisory_list.php" class="btn btn-warning rounded-pill px-5">
                                    <strong>Ir ahora</strong>
                                </a>
                            </div>
                        </div>
                    </div>
                            
                    <div class="col-lg-4 pb-3">
                        <div class="card border-0 shadow h-100">
                            <img class="card-img-top" src="assets/images/thumbnails/thumb_02.jpg" alt="Img 02" />

                            <div class="card-body h-75">
                                <h5 class="card-title">
                                    <strong>Tus cursos y tutoriales</strong>
                                </h5>

                                <p class="card-text">Vea los cursos y tutoriales al que estas inscrito y aprende sobre las tecnologías de la información fácil.</p>
                            </div>

                            <div class="card-body text-center h-25">
                                <a href="courses_list.php" class="btn btn-warning rounded-pill px-5">
                                    <strong>Ir ahora</strong>
                                </a>
                            </div>
                        </div>
                    </div>
                            
                    <div class="col-lg-4 pb-3">
                        <div class="card border-0 shadow h-100">
                            <img class="card-img-top" src="assets/images/thumbnails/thumb_03.jpg" alt="Img 03" />

                            <div class="card-body h-75">
                                <h5 class="card-title">
                                    <strong>Dispositivos adquiridos</strong>
                                </h5>

                                <p class="card-text">Observe la lista de los dispositivos comprados y sus detalles.</p>
                            </div>

                            <div class="card-body text-center h-25">
                                <a href="devices_list.php" class="btn btn-warning rounded-pill px-5">
                                    <strong>Ir ahora</strong>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-8 pb-3">
                        <div class="card border-0 shadow h-100">
                            <img id="service_plan_image" class="card-img" src="assets/images/thumbnails/thumb_04.jpg" alt="Img 04" height="300" />

                            <div id="service_plan_pane" class="card-img-overlay rounded">
                                <div class="row">
                                    <div class="col-7">
                                        <h5 class="card-title">
                                            <strong>Elige como pagar el servicios según tus necesidades</strong>
                                        </h5>

                                        <a href="plans.php" class="btn btn-dark rounded-pill text-nowrap px-5">
                                            <i class="fas fa-tasks mr-1"></i>
                                            <strong>Elegir plan</strong>
                                        </a>
                                    </div>
                                    
                                    <div class="col-5"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-4 pb-3">
                        <div class="card border-0 shadow h-100">
                            <div class="card-body text-center">
                                <h5 class="card-title">
                                    <strong>Paquete de Office 365</strong>
                                </h5>
                                
                                <img src="assets/images/icons/office_365.png" alt="Office 365" height="40" class="mt-2 mb-4" />
                                <img src="assets/images/icons/word.png" alt="Word" height="40" class="mx-2 mt-2 mb-4" />
                                <img src="assets/images/icons/excel.png" alt="Excel" height="40" class="mx-2 mt-2 mb-4" />
                                <img src="assets/images/icons/power_point.png" alt="Power Point" height="40" class="mt-2 mb-4" />

                                <p class="text-justify">Aprende las herramientas de Microsoft Office 365 con nosotros y recibe un descuento de 50% junto con la instalación.</p>
                                
                                <a href="office_pack.php" class="btn btn-sm btn-grape rounded-pill px-5">
                                    <strong>Empezar</strong>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>

        <footer>
            <?php include_once("includes/footer.inc"); ?>
        </footer>
    </body>
</html>