$(document).ready(function(){
    $('#tb_devices_list').dataTable({
        order: [],
        ordering: false,
        info: false,
        language:{
            url: "lib/datatables/lang/es-ES.json",
            searchPlaceholder: "Buscar dispositivo"
        },
        lengthMenu: [
            [10, 25, 50, 100, -1], 
            ["Mostrar 10 dispositivos", "Mostrar 25 dispositivos", "Mostrar 50 dispositivos", "Mostrar 100 dispositivos", "Mostrar todos los dispositivos"]
        ],
    });
});