function user_info_popover_tooltip_repositioning(){
    if(document.getElementById("nav_user_image") != null){
        setTimeout(function(){
            $('#user_info').popover('update');
            $('#nav_user_image').tooltip('update');
        }, 10);
    }
}

function user_info_popover_tooltip_repositioning_timed(){
    if((document.getElementById("nav_user_image") != null) && ($(window).width() < 992)){
        var user_name_tooltip_reposition = setInterval(function(){
            $('#user_info').popover('update');
            $('#nav_user_image').tooltip('update');
        }, 1);

        setTimeout(function(){
            clearInterval(user_name_tooltip_reposition);
        }, 410);
    }
}

function reset_send_email_validation(){
    document.getElementById("send_email_frm").classList.remove('was-validated');
}

function logout(){
    if(confirm("¿Estás seguro de cerrar la sesión?")){
        location.href = "sources/logout.php";
    }
}

function check_phone(input){
    var num = input.value;
    var matches = num.replace(/\s+/g, '').replace(/[^0-9]/gi, '').match(/\d{4,8}/g);
    var match = matches && matches[0] || '';
    var parts = [];

    for(i=0, len=match.length; i<len; i+=4){
        parts.push(match.substring(i, i+4));
    }

    if(parts.length){
        input.value = parts.join('-');
    }else{
        input.value = num;
    }
}

function remove_user_image(){
    if(confirm("¿Estás seguro de eliminar la imagen de perfil?")){
        location.href = "sources/change_user_image_fx.php?delete=1";
    }
}

function show_user_image_name(){
    document.getElementById("user_image_name").innerText = "Cargando…";
}

function show_user_image_file(event){
    var image_output = document.getElementById("user_image_output");
    var image_name = document.getElementById("user_image_name");
    
    image_name.classList.remove("bg-primary");
    image_name.classList.remove("border-primary");

    var file = event.target.files[0];

    if(file != undefined){
        var name_img = file.name;
        var size = file.size / 1024 / 1024;
        var extension = name_img.substring(name_img.lastIndexOf('.'));
        var reader = new FileReader();

        reader.onload = function(event){
            if(((extension == '.jpg') || (extension == '.png')) && (size <= 5)){
                image_output.src = event.target.result;
                image_name.innerText = name_img;
            }else{
                image_name.innerText = "Ningún archivo";
                image_output.src = "sources/get_user_image.php";
                document.getElementById("change_user_image_frm").reset();

                if((extension != '.jpg') || (extension != '.png')){
                    alert("El tipo de archivo no es aceptable, debe ser JPG o PNG.");
                }else if(size > 5){
                    alert("El tamaño del archivo en bytes supera el límite de 5 MB.");
                }
            }
        };

        reader.readAsDataURL(file);
    }else{
        image_name.innerText = "Ningún archivo";
        image_output.src = "sources/get_user_image.php";
    }
}

function drag_drop_user_image_file(){
    var image_file_field = document.getElementById("fl_user_image");
    var image_name = document.getElementById("user_image_name");

    if(image_file_field != null){
        image_file_field.addEventListener('dragover', function(event) {
            event.stopPropagation();
            event.preventDefault();
            event.dataTransfer.dropEffect = 'copy';

            image_name.classList.add("bg-primary");
            image_name.classList.add("border-primary");
            image_name.innerText = "Adjuntando…";
        });

        image_file_field.addEventListener("dragleave", function() {
            image_name.classList.remove("bg-primary");
            image_name.classList.remove("border-primary");
            image_name.innerText = "Ningún archivo";
        });

        image_file_field.addEventListener('drop', show_user_image_file);
    }
}

function show_user_info(first_name, last_name, email){
    $(document).ready(function(){
        $("#user_info").on('shown.bs.popover', function(){
            document.getElementById("popover_user_profile_name").innerText = first_name + " " + last_name;
            document.getElementById("popover_user_profile_email").innerText = email;
        });
    });
}

function build_popover_tooltip_content(type){
    var content = '';

    switch(type){
        case 0:
            content =
                '<div class="text-center">' +
                    '<h5 class="mb-0">' +
                        '<strong>Tu perfil</strong>' +
                    '</h5>' +
                '</div>';
        break;
        case 1:
            content =
                '<div id="usr_info_details">' +
                    '<table class="w-100 mb-2">' +
                        '<tbody>' +
                            '<tr>' +
                                '<td rowspan="2" width="1%">' +
                                    '<button id="btn_popover_change_user_image" class="btn btn-sm btn-grape rounded-circle focus" data-toggle="modal" data-target="#change_user_image_modal" title="Cambiar la imagen de perfil">' +
                                        '<i class="fas fa-paperclip"></i>' +
                                    '</button>' +
                                '</td>' +
                                '<td rowspan="3" class="w-20">' +
                                    '<img id="popover_user_image" src="sources/get_user_image.php" alt="Imagen de perfil" height="120" width="120" class="rounded-circle mr-3" title="Imagen de perfil" />' +
                                '</td>' +
                                '<td width="79%" class="align-bottom">' +
                                    '<h6 class="mb-0">' +
                                        '<i class="fas fa-tag text-secondary mr-1"></i>' +
                                        '<strong id="popover_user_profile_name">Cargando…</strong>' +
                                    '</h6>' +
                                '</td>' +
                            '</tr>' +
                            '<tr>' +
                                '<td width="79%" class="align-top">' +
                                    '<i class="fas fa-envelope text-secondary mr-1"></i>' +
                                    '<small id="popover_user_profile_email">Cargando…</small>' +
                                '</td>' +
                            '</tr>' +
                        '</tbody>' +
                    '</table>' +
                    '<div class="btn-group-vertical w-100">' +
                        '<a href="user_window.php" role="button" class="btn btn-sm btn-dark text-nowrap w-100">' +
                            '<i class="fas fa-columns mr-1"></i>Panel principal' +
                        '</a>' +
                        '<div class="btn-group w-100" role="group" aria-label="Opciones de usuario">' +
                            '<a href="user_details.php" role="button" class="btn btn-sm btn-outline-dark text-nowrap w-50">' +
                                '<i class="fas fa-user mr-1"></i>Ver perfil' +
                            '</a>' +
                            '<button class="btn btn-sm btn-outline-dark text-nowrap w-50" onclick="logout()">' +
                                '<i class="fas fa-sign-out-alt mr-1"></i>Cerrar sesión' +
                            '</button>' +
                        '</div>' +
                    '</div>' +
                '</div>';
        break;
        case 2:
            content =
                '<table>' +
                    '<tr>' +
                        '<td colspan="2">' +
                            '<strong>El archivo debe ser de…</strong>' +
                        '</td>' +
                    '</tr>' +
                    '<tr>' +
                        '<td colspan="2" class="pb-2">5 MB máximo</td>' +
                    '</tr>' +
                    '<tr>' +
                        '<td class="pb-1">' +
                            '<img src="assets/images/icons/jpg_icon.png" alt="JPG icon" height="60" />' +
                        '</td>' +
                        '<td class="pb-1">' +
                            '<img src="assets/images/icons/png_icon.png" alt="PNG icon" height="60" />' +
                        '</td>' +
                    '</tr>' +
                '</table>';
        break;
        case 3:
            content =
                '<table>' +
                    '<tr>' +
                        '<td colspan="2" class="text-left">' +
                            '<p>El CVC es el número de verificación de 3 o 4 dígitos que tienen las tarjetas en la parte frontal o trasera.</p>' +
                        '</td>' +
                    '</tr>' +
                    '<tr>' +
                        '<td>' +
                            '<img src="assets/images/thumbnails/card_01.png" alt="PNG icon" height="120" class="mr-2 mb-1" />' +
                        '</td>' +
                        '<td>' +
                            '<img src="assets/images/thumbnails/card_02.png" alt="PNG icon" height="120" class="mb-1" />' +
                        '</td>' +
                    '</tr>' +
                '</table>';
        break;
    }

    return content;
}

/* ====================================================================== */
/* Events and miscellaneous                                               */
/* ====================================================================== */

$(document).ready(function(){
    /* --- Popovers -------------------------------------------------------------------------- */
    $('#user_info').popover({
        container: '#user_info_pane',
        placement: 'bottom',
        sanitize: false,
        html: true,
        title: build_popover_tooltip_content(0),
        content: build_popover_tooltip_content(1)
    });
    
    /* --- Tooltips -------------------------------------------------------------------------- */
    $('#main_navbar_logo').tooltip({
        container: "#main_navbar_header",
        placement: "bottom",
        title: 'Ir a la página principal'
    });

    $('#nav_user_image').tooltip({
        container: "#user_info",
        placement: "left"
    });

    $('#nav_user_image').tooltip("show");
    $('#nav_user_image').unbind();

    $('#change_user_image_info').tooltip({
        container: "#change_user_image_modal",
        placement: "top",
        sanitize: false,
        html: true,
        title: build_popover_tooltip_content(2)
    });

    $('#add_card_cvc_info').tooltip({
        container: "#add_card_frm",
        placement: "top",
        sanitize: false,
        html: true,
        title: build_popover_tooltip_content(3)
    });

    /* --- Dropdowns -------------------------------------------------------------------------- */
    $('#nav_menu_courses').on('show.bs.dropdown', function(){
        user_info_popover_tooltip_repositioning_timed();
    });
    
    $('#nav_menu_courses').on('hide.bs.dropdown', function(){
        user_info_popover_tooltip_repositioning_timed();
    });

    /* --- Collapses -------------------------------------------------------------------------- */
    $('#main_navbar').on('show.bs.collapse', function(){
        user_info_popover_tooltip_repositioning();
    });

    /* --- Navs -------------------------------------------------------------------------- */
    $('.nav-link').on('shown.bs.tab', function(){
        user_info_popover_tooltip_repositioning();
    });

    /* --- Modals -------------------------------------------------------------------------- */
    $('#change_user_image_modal').on('hidden.bs.modal', function(){
        document.getElementById("user_image_output").src = "sources/get_user_image.php";
        document.getElementById("user_image_name").innerText = "Ningún archivo";
        document.getElementById("change_user_image_frm").classList.remove('was-validated');
        document.getElementById("change_user_image_frm").reset();
    });

    /* --- Forms -------------------------------------------------------------------------- */
    (function(){
        'use strict';
        window.addEventListener('load', function(){
            Array.prototype.filter.call(document.getElementsByClassName('needs-validation'), function(form){
                if(typeof InstallTrigger === 'undefined'){
                    form.noValidate = true;
                }

                form.addEventListener('submit', function(event){
                    if (form.checkValidity() === false){
                        event.preventDefault();
                        event.stopPropagation();
                    }else{
                        $('.modal').modal('hide');
                    }
    
                    form.classList.add('was-validated');
                }, false);
            });
        }, false);
    })();

    /* --- Other functions -------------------------------------------------------------------------- */
    user_info_popover_tooltip_repositioning();
    drag_drop_user_image_file();
});